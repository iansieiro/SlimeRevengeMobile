using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class WayPoints : MonoBehaviour
{
    public Transform[] points1;
    public Transform[] points2;
    public Transform[] points3;
    public Transform[] points4;
    public Transform[] points5;

}
