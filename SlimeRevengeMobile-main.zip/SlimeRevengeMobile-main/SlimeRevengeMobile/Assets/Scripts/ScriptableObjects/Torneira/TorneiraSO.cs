using UnityEngine;

[CreateAssetMenu(fileName = "Torneira", menuName = "Torneira")]
public class TorneiraSO : ScriptableObject
{
    public Sprite arteTorneira;
}
